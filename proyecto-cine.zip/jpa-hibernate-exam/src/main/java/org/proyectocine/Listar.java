package org.proyectocine;

import jakarta.persistence.EntityManager;
import org.proyectocine.entity.*;
import org.proyectocine.util.JpaUtil;

import java.util.List;

public class Listar {

    public static void main(String[] args){

        EntityManager em = JpaUtil.getEntityManager();

        System.out.println("\n ======== Listar Tabla Peliculas ========");
        List<Pelicula> pelicula = em.createQuery("select c from Pelicula c",
                        Pelicula.class)
                .getResultList();
        pelicula.forEach(System.out::println);

        //em.close();

        System.out.println("\n======== Listar Tabla Actores ========");
        List<Actor> actor = em.createQuery("select c from Actor c",
                        Actor.class)
                .getResultList();
        actor.forEach(System.out::println);

        System.out.println("\n======== Listar Tabla Directores ========");
        List<Director> director = em.createQuery("select c from Director c",
                        Director.class)
                .getResultList();
        director.forEach(System.out::println);

        System.out.println("\n======== Listar Tabla Gana Premio ========");
        List<GanaPremio> ganapremio = em.createQuery("select c from GanaPremio c",
                        GanaPremio.class)
                .getResultList();
        ganapremio.forEach(System.out::println);

        System.out.println("\n======== Listar Tabla Participa ========");
        List<Participa> participa = em.createQuery("select c from Participa c",
                        Participa.class)
                .getResultList();
        participa.forEach(System.out::println);

        System.out.println("\n======== Listar Tabla Premio ========");
        List<Premio> premio = em.createQuery("select c from Premio c",
                        Premio.class)
                .getResultList();
        premio.forEach(System.out::println);

        em.close();



    }

}
