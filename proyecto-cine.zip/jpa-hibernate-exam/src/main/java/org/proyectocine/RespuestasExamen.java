package org.proyectocine;

import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.ParameterExpression;
import jakarta.persistence.criteria.Root;
import org.proyectocine.entity.Actor;
import org.proyectocine.entity.Pelicula;
import org.proyectocine.util.JpaUtil;

import java.util.List;

public class RespuestasExamen {

    public static void main(String[] args) {

        EntityManager em = JpaUtil.getEntityManager();
        try {

            System.out.println("\n 6.\t¿Qué empresa es la distribuidora de la película ‘Casablanca’?");
            Pelicula mov = em.createQuery("select c from Pelicula c where c.titulo=?1", Pelicula.class)
                    .setParameter(1,"Casablanca")
                    .getSingleResult();
            System.out.println("La distribuidora de la pelicula '"+ mov.getTitulo() + "' es: "+ mov.getDistribuidora());

            System.out.println("\n 7.\tMuestra qué actores y actrices, nacidos en Suecia, han fallecido ya, según la información almacenada en nuestra base de datos.");
            Actor actorSuecia = em.createQuery("select c from Actor c where c.nacionalidad=?1", Actor.class)
                    .setParameter(1,"Suecia")
                    .getSingleResult();
            if (actorSuecia.getfMuerte() != null) {
                System.out.println("Nombre del Actor/Actriz: " + actorSuecia.getNombre() + "\nNacionalidad: " + actorSuecia.getNacionalidad() + "\nFecha de Fallecimiento: " + actorSuecia.getfMuerte());
            }

            System.out.println("\n 9.\tMuestra el nombre y lugar de nacimiento de las actrices que actuaban en la película ‘Solas’.");
            Pelicula actrices = em.createQuery("select c from Pelicula c where c.titulo=?1", Pelicula.class)
                    .setParameter(1,"Solas")
                    .getSingleResult();
            System.out.println("El reparto de actrices de la pelicula '"+ actrices.getTitulo() + "' son: "+ actrices.getActores());


            System.out.println("\n 11.\tSaca un listado de las películas españolas, pero en el que en el mismo campo aparezca el título seguido del año entre paréntesis (p.e.: El Bola (2000).");
            CriteriaBuilder criteria = em.getCriteriaBuilder();
            CriteriaQuery<Pelicula> criteriaQry = criteria.createQuery(Pelicula.class);
            Root<Pelicula> from = criteriaQry.from(Pelicula.class);
            criteriaQry.select(from);
            List<Pelicula> peliculaSpain = em.createQuery(criteriaQry).getResultList();
            //peliculaSpain.forEach(System.out::println); //Enlistar todas las peliculas antes de filtrar por pais
            criteriaQry = criteria.createQuery(Pelicula.class);
            from = criteriaQry.from(Pelicula.class);
            ParameterExpression<String> nombreParamLike = criteria.parameter(String.class, "nombreParam");
            criteriaQry.select(from).where(criteria.like(criteria.upper(from.get("nacionalidad")),criteria.upper(nombreParamLike)));
            peliculaSpain = em.createQuery(criteriaQry).setParameter("nombreParam", "España")
                    .getResultList();
            peliculaSpain.forEach(System.out::println);

            System.out.println("\n 12.\t¿Quién es el actor que ha participado en más películas?");
            Actor actor1 = em.createQuery("select c from Actor c where c.nombre=?1", Actor.class)
                    .setParameter(1,"Orlando Bloom")
                    .getSingleResult();
            System.out.println("El actor '"+ actor1.getNombre() + "' ha participado en "+ actor1.getPeliculas().size()+ " peliculas");


        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }

    }
}
