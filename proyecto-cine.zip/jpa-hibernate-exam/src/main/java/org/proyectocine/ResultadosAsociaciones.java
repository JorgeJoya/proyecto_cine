package org.proyectocine;

import jakarta.persistence.EntityManager;

import jakarta.persistence.Query;
import org.proyectocine.entity.Pelicula;
import org.proyectocine.util.JpaUtil;

import java.util.List;

public class ResultadosAsociaciones {

    public static void main(String[] args) {


        EntityManager em = JpaUtil.getEntityManager();

        try {
            System.out.println("\n ------------  Lista de Peliculas y sus actores ------------ ");
            em.getTransaction().begin();
            Pelicula pelicula = em.find(Pelicula.class,3L);
            System.out.println("Pelicula: "+pelicula.getTitulo()+", Actores: "+pelicula.getActores());
            Pelicula pelicula1 = em.find(Pelicula.class,4L);
            System.out.println("Pelicula: "+pelicula1.getTitulo()+", Actores: "+pelicula1.getActores());
            Pelicula pelicula2 = em.find(Pelicula.class,9L);
            System.out.println("Pelicula: "+pelicula2.getTitulo()+", Actores: "+pelicula2.getActores());
            Pelicula pelicula3 = em.find(Pelicula.class,5L);
            System.out.println("Pelicula: "+pelicula3.getTitulo()+", Actores: "+pelicula3.getActores());

            System.out.println("\n ------------  Lista de Peliculas y sus premios ------------ ");
            Pelicula movie = em.find(Pelicula.class,6L);
            System.out.println("Pelicula: "+movie.getTitulo()+", Premios: "+movie.getPremios());
            Pelicula movie1 = em.find(Pelicula.class,10L);
            System.out.println("Pelicula: "+movie1.getTitulo()+", Premios: "+movie1.getPremios());

            System.out.println("\n ------------  Lista de Peliculas y sus directores ------------ ");
            Pelicula mov1 = em.find(Pelicula.class,10L);
            System.out.println("Pelicula: "+mov1.getTitulo()+", Director: "+mov1.getDirectores());
            Pelicula mov = em.find(Pelicula.class,3L);
            System.out.println("Pelicula: "+mov.getTitulo()+", Director: "+mov.getDirectores());

            System.out.println("\n ------------  Buscar pelicula por titulo ------------ ");
            Query qry = em.createQuery("select c from Pelicula c where c.titulo=?1", Pelicula.class);
            String movi = "Casablanca";
            qry.setParameter(1, movi);
            qry.setMaxResults(2);
            List<Pelicula> pelicul = qry.getResultList();
            System.out.println(pelicul);

            System.out.println("\n ------------  Buscar pelicula por distribuidora ------------ ");
            Query query = em.createQuery("select c from Pelicula c where c.distribuidora=?1", Pelicula.class);
            String distribuidora = "C.B. Fimls S.A.";
            query.setParameter(1, distribuidora);
            query.setMaxResults(2);
            List<Pelicula> peliculas = query.getResultList();
            System.out.println(peliculas);

        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }

    }
}
