package org.proyectocine.repositories;

import jakarta.persistence.EntityManager;
//import org.jjoya.proyectocine.entity.Pelicula;
import org.proyectocine.entity.Pelicula;

import java.util.List;

public class PeliculaRepository implements CrudRepository<Pelicula> {
    private EntityManager em;
    public PeliculaRepository(EntityManager em) {
        this.em = em;
    }
    @Override
    public List<Pelicula> listar() {
        return em.createQuery("select c from Pelicula c",
                Pelicula.class).getResultList();
    }
    @Override
    public Pelicula porCodPelicula(Long codPelicula) {
        return em.find(Pelicula.class, codPelicula);
    }
    @Override
    public void guardar(Pelicula pelicula) {
        if(pelicula.getCodPelicula() != null && pelicula.getCodPelicula() > 0) {
            em.merge(pelicula);
        } else {
            em.persist(pelicula);
        }
    }
    @Override
    public void eliminar(Long codPelicula) {
        Pelicula pelicula = porCodPelicula(codPelicula);
        em.remove(pelicula);
    }

}
