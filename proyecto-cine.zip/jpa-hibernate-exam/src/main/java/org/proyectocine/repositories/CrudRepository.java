package org.proyectocine.repositories;

import java.util.List;

public interface CrudRepository<T>  {
    List<T> listar();
    T porCodPelicula(Long codPelicula);
    void guardar(T t);
    void eliminar(Long codPelicula);
}
