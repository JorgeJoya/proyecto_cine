package org.proyectocine.services;

//import org.jjoya.proyectocine.entity.Pelicula;

import org.proyectocine.entity.Pelicula;

import java.util.List;
import java.util.Optional;

public interface PeliculaService {
    List<Pelicula> listar();
    Optional<Pelicula> porCodPelicula(Long CodPelicula);
    void guardar(Pelicula pelicula);
    void eliminar(Long CodPelicula);
}
