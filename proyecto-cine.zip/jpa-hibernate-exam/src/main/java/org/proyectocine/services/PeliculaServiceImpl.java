package org.proyectocine.services;

import jakarta.persistence.EntityManager;
//import org.jjoya.proyectocine.entity.Pelicula;
//import org.jjoya.proyectocine.repositories.CrudRepository;
//import org.jjoya.proyectocine.repositories.PeliculaRepository;
import org.proyectocine.entity.Pelicula;
import org.proyectocine.repositories.CrudRepository;
import org.proyectocine.repositories.PeliculaRepository;

import java.util.List;
import java.util.Optional;

public class PeliculaServiceImpl {
    private EntityManager em;
    private CrudRepository<Pelicula> repository;
    public PeliculaServiceImpl(EntityManager em) {
        this.em = em;
        this.repository = new PeliculaRepository(em);
    }

    public List<Pelicula> listar() {
        return repository.listar();
    }

    public Optional<Pelicula> porCodPelicula(Long codPelicula) {
        return Optional.ofNullable(repository.porCodPelicula(codPelicula));
    }

    public void guardar(Pelicula pelicula) {
        try {
            em.getTransaction().begin();
            repository.guardar(pelicula);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    public void eliminar(Long codPelicula) {
        try {
            em.getTransaction().begin();
            repository.eliminar(codPelicula);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }
}
