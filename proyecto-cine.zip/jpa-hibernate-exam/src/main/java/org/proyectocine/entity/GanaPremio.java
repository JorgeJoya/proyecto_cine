package org.proyectocine.entity;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name="ganapremio")
public class GanaPremio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="CodPelicula")
    private Long codPelicula;
    @Column(name="CodPremio")
    private Long codPremio;
    @Column(name="Anyo")
    private Long anyo;

    public GanaPremio (){}
    public GanaPremio(Long codPelicula, Long codPremio, Long anyo) {
        this.codPelicula = codPelicula;
        this.codPremio = codPremio;
        this.anyo = anyo;
    }

    public Long getCodPelicula() {
        return codPelicula;
    }

    public void setCodPelicula(Long codPelicula) {
        this.codPelicula = codPelicula;
    }

    public Long getCodPremio() {
        return codPremio;
    }

    public void setCodPremio(Long codPremio) {
        this.codPremio = codPremio;
    }

    public Long getAnyo() {
        return anyo;
    }

    public void setAnyo(Long anyo) {
        this.anyo = anyo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GanaPremio that = (GanaPremio) o;
        return Objects.equals(codPelicula, that.codPelicula) && Objects.equals(codPremio, that.codPremio) && Objects.equals(anyo, that.anyo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codPelicula, codPremio, anyo);
    }

    @Override
    public String toString() {
        return "GanaPremio{" +
                "codPelicula=" + codPelicula +
                ", codPremio=" + codPremio +
                ", anyo=" + anyo +
                '}';
    }
}
