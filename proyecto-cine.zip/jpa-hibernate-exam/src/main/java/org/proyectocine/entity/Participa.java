package org.proyectocine.entity;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name="participa")
public class Participa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="CodActor")
    private Long codActor;
    @Column(name="CodPelicula")
    private Long codPelicula;

    public Participa (){}

    public Participa(Long codActor, Long codPelicula) {
        this.codActor = codActor;
        this.codPelicula = codPelicula;
    }

    public Long getCodActor() {
        return codActor;
    }

    public void setCodActor(Long codActor) {
        this.codActor = codActor;
    }

    public Long getCodPelicula() {
        return codPelicula;
    }

    public void setCodPelicula(Long codPelicula) {
        this.codPelicula = codPelicula;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Participa participa = (Participa) o;
        return Objects.equals(codActor, participa.codActor) && Objects.equals(codPelicula, participa.codPelicula);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codActor, codPelicula);
    }

    @Override
    public String toString() {
        return "Participa{" +
                "codActor=" + codActor +
                ", codPelicula=" + codPelicula +
                '}';
    }
}
