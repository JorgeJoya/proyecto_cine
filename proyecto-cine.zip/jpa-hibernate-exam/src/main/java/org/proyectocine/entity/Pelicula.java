package org.proyectocine.entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name="pelicula")
public class Pelicula {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="codPelicula")
    private Long codPelicula;
    @Column(name="Titulo")
    private String titulo;
    @Column(name="Anyo")
    private String anyo;
    @Column(name="Nacionalidad")
    private String nacionalidad;
    @Column(name="Duracion")
    private double duracion;
    @Column(name="FechaEstreno")
    private Date fechaEstreno;
    @Column(name="Genero")
    private Long genero ;
    @Column(name="Taquilla")
    private double taquilla;
    @Column(name="Productora")
    private String productora;
    @Column(name="Distribuidora")
    private String distribuidora;
    @Column(name="Director")
    private Long director;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    //@JoinColumn(name = "codPelicula")
    @JoinTable(name = "participa", joinColumns = @JoinColumn(name = "codPelicula")
            , inverseJoinColumns = @JoinColumn(name = "codActor")
           , uniqueConstraints = @UniqueConstraint(columnNames = {"codActor"}))
    private List<Actor> actores;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    //@JoinColumn(name = "codPremio")
    @JoinTable(name = "GanaPremio", joinColumns = @JoinColumn(name = "codPelicula")
            , inverseJoinColumns = @JoinColumn(name = "codPremio")
            , uniqueConstraints = @UniqueConstraint(columnNames = {"codPremio"}))
    private List<Premio> premios;

   @OneToMany (cascade = CascadeType.ALL, orphanRemoval = true)
   @JoinColumn(name = "codDirector")
   //@UniqueConstraint(columnNames = {"codDirector"})
   private List<Director> directores;

    public Pelicula(){
        actores = new ArrayList<>();
        premios = new ArrayList<>();
        directores = new ArrayList<>();
    }
    public Pelicula(String titulo) {
        this.titulo = titulo;
    }

    public Pelicula(Long codPelicula,
                    String titulo,
                    String anyo,
                    double duracion,
                    String productora,
                    String distribuidora) {

        this.codPelicula = codPelicula;
        this.titulo = titulo;
        this.anyo = anyo;
        this.duracion = duracion;
        this.productora = productora;
        this.distribuidora = distribuidora;
    }

    public Long getCodPelicula() {
        return codPelicula;
    }

    public void setCodPelicula(Long codPelicula) {
        this.codPelicula = codPelicula;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAnyo() {
        return anyo;
    }

    public void setAnyo(String anyo) {
        this.anyo = anyo;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public double getDuracion() {
        return duracion;
    }

    public void setDuracion(double duracion) {
        this.duracion = duracion;
    }

    public Date getFechaEstreno() {
        return fechaEstreno;
    }

    public void setFechaEstreno(Date fechaEstreno) {
        this.fechaEstreno = fechaEstreno;
    }

    public Long getGenero() {
        return genero;
    }

    public void setGenero(Long genero) {
        this.genero = genero;
    }

    public double getTaquilla() {
        return taquilla;
    }

    public void setTaquilla(double taquilla) {
        this.taquilla = taquilla;
    }

    public String getProductora() {
        return productora;
    }

    public void setProductora(String productora) {
        this.productora = productora;
    }

    public String getDistribuidora() {
        return distribuidora;
    }

    public void setDistribuidora(String distribuidora) {
        this.distribuidora = distribuidora;
    }

    public Long getDirector() {
        return director;
    }

    public void setDirector(Long director) {
        this.director = director;
    }

    public List<Actor> getActores() {
        return actores;
    }

    public void setActores(List<Actor> actores) {
        this.actores = actores;
    }

    public List<Premio> getPremios() {
        return premios;
    }

    public void setPremios(List<Premio> premios) {
        this.premios = premios;
    }

    public List<Director> getDirectores() {
        return directores;
    }

    public void setDirectores(List<Director> directores) {
        this.directores = directores;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pelicula pelicula = (Pelicula) o;
        return Double.compare(pelicula.duracion, duracion) == 0 && Double.compare(pelicula.taquilla, taquilla) == 0 && Objects.equals(codPelicula, pelicula.codPelicula) && Objects.equals(titulo, pelicula.titulo) && Objects.equals(anyo, pelicula.anyo) && Objects.equals(nacionalidad, pelicula.nacionalidad) && Objects.equals(fechaEstreno, pelicula.fechaEstreno) && Objects.equals(genero, pelicula.genero) && Objects.equals(productora, pelicula.productora) && Objects.equals(distribuidora, pelicula.distribuidora) && Objects.equals(director, pelicula.director);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codPelicula, titulo, anyo, nacionalidad, duracion, fechaEstreno, genero, taquilla, productora, distribuidora, director);
    }

    @Override
    public String toString() {
        return //"Pelicula{" +
             //   "codPelicula=" + codPelicula +
              //  ", titulo='" +
                        titulo +
                                //'\'' +
                //", anyo='" +
                                "("+
                                anyo +
                                        //'\'' +
                                        ")" //+
              //  ", nacionalidad='" + nacionalidad + '\'' +
              //  ", duracion=" + duracion +
              //  ", fechaEstreno=" + fechaEstreno +
             //   ", genero=" + genero +
             //   ", taquilla=" + taquilla +
              //  ", productora='" + productora + '\'' +
              //  ", distribuidora='" + distribuidora + '\'' +
              //  ", director=" + director +
              //  '}'
        ;
    }
}
