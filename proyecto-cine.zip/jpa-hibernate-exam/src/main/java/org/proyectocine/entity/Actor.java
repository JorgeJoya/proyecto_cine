package org.proyectocine.entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name="actor")
public class Actor {
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="CodActor")
    private Long codActor;
    @Column(name="Nombre")
    private String nombre;
    private Date fNacimiento;
    private String lNacimiento;
    private String nacionalidad;
    private Date fMuerte;
    private String lMuerte;

 @OneToMany (cascade = CascadeType.ALL, orphanRemoval = true)//(mappedBy = "actor")
 //@JoinColumn(name = "codPelicula")
 //@JoinColumn(name = "codPelicula")
 @JoinTable(name = "participa", joinColumns = @JoinColumn(name = "codActor")
         , inverseJoinColumns = @JoinColumn(name = "codPelicula")
         , uniqueConstraints = @UniqueConstraint(columnNames = {"codPelicula"}))
 private List<Pelicula> peliculas;

 //public Actor(){}

 public Actor() {this.peliculas = new ArrayList<>();
 }

 public Actor(String nombre) {
  this.nombre = nombre;
 }

 public Long getCodActor() {
  return codActor;
 }

 public void setCodActor(Long codActor) {
  this.codActor = codActor;
 }

 public String getNombre() {
  return nombre;
 }

 public void setNombre(String nombre) {
  this.nombre = nombre;
 }

 public Date getfNacimiento() {
  return fNacimiento;
 }

 public void setfNacimiento(Date fNacimiento) {
  this.fNacimiento = fNacimiento;
 }

 public String getlNacimiento() {
  return lNacimiento;
 }

 public void setlNacimiento(String lNacimiento) {
  this.lNacimiento = lNacimiento;
 }

 public String getNacionalidad() {
  return nacionalidad;
 }

 public void setNacionalidad(String nacionalidad) {
  this.nacionalidad = nacionalidad;
 }

 public Date getfMuerte() {
  return fMuerte;
 }

 public void setfMuerte(Date fMuerte) {
  this.fMuerte = fMuerte;
 }

 public String getlMuerte() {
  return lMuerte;
 }

 public void setlMuerte(String lMuerte) {
  this.lMuerte = lMuerte;
 }

 public List<Pelicula> getPeliculas() {
  return peliculas;
 }

 public void setPeliculas(List<Pelicula> peliculas) {
  this.peliculas = peliculas;
 }

 @Override
 public boolean equals(Object o) {
  if (this == o) return true;
  if (o == null || getClass() != o.getClass()) return false;
  Actor actor = (Actor) o;
  return codActor == actor.codActor && Objects.equals(nombre, actor.nombre) && Objects.equals(fNacimiento, actor.fNacimiento) && Objects.equals(lNacimiento, actor.lNacimiento) && Objects.equals(nacionalidad, actor.nacionalidad) && Objects.equals(fMuerte, actor.fMuerte) && Objects.equals(lMuerte, actor.lMuerte);
 }

 @Override
 public int hashCode() {
  return Objects.hash(codActor, nombre, fNacimiento, lNacimiento, nacionalidad, fMuerte, lMuerte);
 }

 @Override
 public String toString() {
  return //"Actor{" +
          //"codActor=" + codActor +","+
          " nombre: " + nombre + //'\'' +
          //", fNacimiento=" + fNacimiento +
          ", lugar de Nacimiento: " + lNacimiento //+ '\'' +
         // ", nacionalidad: " + nacionalidad //+ '\''+
          //", fMuerte=" + fMuerte +
         // ", lMuerte='" + lMuerte + '\'' +
          //'}'
          ;
 }


}
