package org.proyectocine.entity;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name="premio")
public class Premio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="codPremio")
    private Long codPremio;
    @Column(name="Premio")
    private String premio;

    public Premio() {
    }

    public Premio(Long codPremio, String premio) {
        this.codPremio = codPremio;
        this.premio = premio;
    }

    public Long getCodPremio() {
        return codPremio;
    }

    public void setCodPremio(Long codPremio) {
        this.codPremio = codPremio;
    }

    public String getPremio() {
        return premio;
    }

    public void setPremio(String premio) {
        this.premio = premio;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Premio premio1 = (Premio) o;
        return codPremio == premio1.codPremio && Objects.equals(premio, premio1.premio) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(codPremio, premio);
    }

    @Override
    public String toString() {
        return //"Premio{" +
                //"codPremio=" + codPremio +","+
                " premio: " + premio //+ '\'' +
              //  '}'
        ;
    }
}
