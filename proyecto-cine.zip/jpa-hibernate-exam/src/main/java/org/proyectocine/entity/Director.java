package org.proyectocine.entity;

import jakarta.persistence.*;

import java.util.Date;
import java.util.Objects;

@Entity
@Table(name="director")
public class Director {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="codDirector")
    private Long codDirector;
    @Column(name="Nombre")
    private String nombre;
    private Date fNacimiento;
    private String lNacimiento;
    private String nacionalidad;
    private Date fMuerte;
    private String lMuerte;

    //@ManyToMany
   // @JoinColumn (name="codPelicula")
   // private List<Pelicula> peliculas;


    public Director (){}
    public Director(String nombre){
        this.nombre = nombre;
    }
    //public Director() {this.peliculas = new ArrayList<>();
    //}

    public Long getCodDirector() {
        return codDirector;
    }

    public void setCodDirector(Long codDirector) {
        this.codDirector = codDirector;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getfNacimiento() {
        return fNacimiento;
    }

    public void setfNacimiento(Date fNacimiento) {
        this.fNacimiento = fNacimiento;
    }

    public String getlNacimiento() {
        return lNacimiento;
    }

    public void setlNacimiento(String lNacimiento) {
        this.lNacimiento = lNacimiento;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public Date getfMuerte() {
        return fMuerte;
    }

    public void setfMuerte(Date fMuerte) {
        this.fMuerte = fMuerte;
    }

    public String getlMuerte() {
        return lMuerte;
    }

    public void setlMuerte(String lMuerte) {
        this.lMuerte = lMuerte;
    }

    //public List<Pelicula> getPeliculas() {
    //    return peliculas;
   // }

   // public void setPeliculas(List<Pelicula> peliculas) {
    //    this.peliculas = peliculas;
    //}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Director director = (Director) o;
        return codDirector == director.codDirector && Objects.equals(nombre, director.nombre) && Objects.equals(fNacimiento, director.fNacimiento) && Objects.equals(lNacimiento, director.lNacimiento) && Objects.equals(nacionalidad, director.nacionalidad) && Objects.equals(fMuerte, director.fMuerte) && Objects.equals(lMuerte, director.lMuerte) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(codDirector, nombre, fNacimiento, lNacimiento, nacionalidad, fMuerte, lMuerte);
    }

    @Override
    public String toString() {
        return //"Director{" +
                //"codDirector=" + codDirector +","+
                " nombre: " + nombre + //'\'' +
               // ", fNacimiento=" + fNacimiento +
               // ", lNacimiento='" + lNacimiento + '\'' +
                ", nacionalidad: " + nacionalidad //+ '\'' +
               // ", fMuerte=" + fMuerte +
              //  ", lMuerte='" + lMuerte + '\'' +
              // '}'
                ;
    }


}
